# Hpoi EXHOBBY · Quantumult X / Surge / Loon

在 Hpoi iOS App 的手办词条相册列表中添加「EXHOBBY 相册」入口，点击后通过 Hpoi 原生相册查看图片。

当前多客户端适配版：**v3.7.2**。自动识别不同手办词条，为每个条目分别保存图库和分页数据。每个词条只新增一个独立「EXHOBBY 相册」入口；全部 EXHOBBY 图片只显示在这个专用相册中，普通 Hpoi 相册保持原样。

本适配版基于 GitHub `main` 在 2026-09-27 的提交 `29c0848`（v3.7.1）制作。

| 客户端 | EXHOBBY 相册 | Hpoi 接口净化 | 第三方广告域名 |
| --- | --- | --- | --- |
| Quantumult X | 完整支持 | 淘宝卡片清理 | 完整拒绝 |
| Surge | 完整支持 | 淘宝卡片清理 | 完整拒绝 |
| Loon | 完整支持 | 淘宝卡片清理 | 完整拒绝 |
| Clash / Mihomo | 不支持 | 不支持 | 支持 |

Hpoi 官方 `/api/common/advert/list` 在 v3.7.2 中只做一项定向处理：把识别出的开屏列表收缩为一个明确的 Hpoi 官方记录，响应中的配置、时间间隔、素材参数及其他数组全部保留；第三方广告域名仍全部拒绝。Clash/Mihomo 核心没有本项目需要的 HTTPS MITM 请求/响应 JavaScript 环境，因此只能使用随仓库提供的第三方广告域名规则，不能注入 EXHOBBY 相册或清理淘宝卡片。

## v3.7.2 定向保留官方开屏

- 重写 QX、Surge、Loon 的开屏处理：只修改被识别为开屏列表的那一个数组，并只保留一个带 `official`／`isOfficial`、Hpoi 来源字段或 Hpoi 官方域名信号的记录。
- v3.7.1 会递归清空响应里的其他数组；v3.7.2 不再这样做，配置、时间间隔、素材列表及父级／同级记录全部保持原样。
- 新增固定路径 `hpoi-ad-sanitize-v3.7.2.js` 规避客户端脚本缓存；旧 `hpoi-ad-sanitize-v3.7.1.js` 改为 `$done({})`，即使旧规则残留也不会继续执行有问题的递归清理。
- `hpoi-ads-filter.list`、Surge 模块、Loon 插件与 Clash/Mihomo 规则仍拒绝全部已收录的第三方广告域名。
- 淘宝关联商品清理、EXHOBBY 相册、20 张懒加载和 7 天缓存回收保持不变。
- 无法明确识别官方记录或响应结构变化时整包原样放行，第三方内容仍由域名规则拒绝；如果仍无法启动，需要依据真机请求日志定位被 Hpoi 启动流程硬依赖的第三方 SDK 接口，不能继续靠猜测放行。

## v3.7.1 保留一个官方开屏

- Hpoi 自家 `/api/common/advert/list` 不再把全部广告数组清空，而是从服务器原始响应中保留一个开屏记录，保证冷启动流程仍有合法数据可读取。
- 优先识别 `splash`、`startup`、`launch`、`boot`、`advert` 等开屏数组；存在 Hpoi 官方域名或 `official` 标记时优先保留该记录。
- 保留记录内的图片、素材和其他嵌套数组原样不动，其余广告数组继续清空。
- 不伪造图片、链接或广告对象；如果后端结构无法安全识别，直接放行服务器原响应，优先保证 App 能进入。
- Quantumult X、Surge、Loon 统一改用固定路径 `hpoi-ad-sanitize-v3.7.1.js`，避免继续命中旧脚本缓存。Clash/Mihomo 规则不变。

## v3.7.0 多客户端适配

- 主脚本改为 Quantumult X、Surge、Loon 共用的单一运行文件；相册抓取、独立相册、20 张懒加载和 7 天缓存回收逻辑保持一致。
- 新增统一存储、HTTP 请求、通知、响应状态码和 `$done` 结果适配层。
- 请求/响应关联同时支持 Quantumult X `sessionIndex`、Surge 请求 ID，以及 Loon 无请求 ID 时的脱敏指纹后备；指纹只包含公开路由字段，不保存 Hpoi `utoken`。
- 新增 Surge 模块 `hpoi-exhobby.sgmodule`、Loon 插件 `hpoi-exhobby.plugin`。
- 新增 Clash/Mihomo classical rule-provider `hpoi-ads-clash.yaml` 和合并示例 `hpoi-clash-example.yaml`。
- 修复上游 v3.6.2 已存在的短原生分页缺口：无法在不额外请求 Hpoi 的情况下重建连续页时，保留当前 Hpoi 原生页，不再替换为空列表。
- 三个平台的验证通知现在都会携带可点击的 EXHOBBY 地址；Bark 仍为可选后备方式。

## v3.6.2 EXHOBBY 子图库 20 张懒加载

- 普通/独立 Hpoi 相册中的 EXHOBBY 子图库不再一次性把全部图片塞进第一页。
- 输出分页严格按 Hpoi 请求的 `pageSize` 计算；常见情况下每页最多 20 张。
- EXHOBBY 图片优先，EXHOBBY 用完后立即用 Hpoi 原生图片补满当前页，保持连续顺序。
- 示例：EXHOBBY 26 张 + Hpoi 18 张时，page 1 = EX 1–20；page 2 = EX 21–26 + Hpoi 1–14；page 3 = Hpoi 15–18。
- 示例：EXHOBBY 152 张 + Hpoi 18 张时，page 1–7 各 20 张 EX；page 8 = 12 张 EX + 8 张 Hpoi；page 9 = 剩余 10 张 Hpoi。
- 脚本不会额外向 Hpoi 发隐藏分页请求；只缓存 Hpoi 本来返回的原生图片元数据，并在后续输出页按需消费。
- 尚未翻到的 EXHOBBY 图片不会提前暴露给 Hpoi 图片列表，有助于减少缩略图预加载、内存占用和 Hpoi App 图片缓存增长。
- 原生分页元数据缓存跟随相册缓存一起回收，并继续受 7 天未查看 GC 控制。
- v3.6.1 的 7 天词条/相册自动回收、缓存状态页和 v3.6.0 的独立相册支持全部保留。

## v3.6.1 七天未查看自动回收 + 缓存状态页

- 词条和相册改为独立记录最后查看时间。
- 连续 7 天未查看的词条会自动回收其 EXHOBBY 整条目图库、子图库、图片映射、路由映射和分页临时缓存。
- 即使词条本身经常打开，其中连续 7 天没点过的普通/独立相册也会单独回收自己的 EXHOBBY 子图库缓存。
- 普通相册出现在词条列表中只会登记归属，不会刷新该相册的“最后查看时间”；只有真正打开相册并解析其 EXHOBBY 子图库时才刷新。
- 自动 GC 最多每 6 小时真正检查一次；每次检查都会输出 `cache GC checked ...` 日志，即使 `removed=0` 也可确认 GC 已执行。
- 为防止短期大量浏览时过早淘汰，词条安全上限由 8 个放宽至 32 个；7 天未查看仍是主要回收条件。
- 新增缓存状态页：在 Safari 打开 `https://www.exhobby.net/__hpoi_cache_status__`，可查看已跟踪词条/相册、超过 7 天未查看数量、上次 GC 和距离下次检查时间。
- 手动清理入口仍为 `https://www.exhobby.net/__hpoi_cache_clear__`，并继续保留 Safari 年龄验证会话和通知设置。
- 自动 GC 仍由 HPOI/EXHOBBY 请求触发；完全不使用 HPOI 时，代理客户端不会自行后台唤醒。

## v3.6.0 独立相册自注册

- 修复从“非条目页”直接打开 Hpoi 独立相册时，`pic/list/relate-v2` 为 `virtual=none`、因此不注入 EXHOBBY 图片的问题。
- 独立相册第一次经过 `album/detail` 时，会自动记录自己的 `id ↔ itemId`。
- 后续该独立相册的图片列表请求会识别为 `standalone-owner`，并直接使用自己的 `itemId` 请求 EXHOBBY：`itemId=<独立相册 itemId>&itemType=album`。
- 不需要先从某个条目页打开一次，也不依赖 `hobby/album` 归属映射。
- 独立相册仍然只注入自己在 EXHOBBY 中的子图库，不会回退成整条目图库。
- 实机日志中的 `id=40154473 itemId=404807` 已按该链路模拟验证：独立相册自注册后成功注入其自身 EXHOBBY 子图库。
- v3.5.9 的普通相册子图库、自动缓存 GC 和手动清缓存入口继续保留。

## v3.5.9 普通相册独立 EXHOBBY 子图库 + 缓存清理

- 普通 Hpoi 相册不再注入整条目的全部 EXHOBBY 图片。
- 每个普通相册会使用自己的 `itemId` 请求 EXHOBBY：`itemId=<当前相册>&itemType=album`，只注入该相册在 EXHOBBY 中自己的图片。
- 如果 EXHOBBY 没有该相册的独立图库，保持原 Hpoi 相册，不注入其它相册或整条目图片。
- 当一个词条有多个普通相册、但 EXHOBBY 的相册接口错误地返回与整条目完全相同的全集时，脚本会识别并跳过注入，防止再次把全集塞进每个相册。
- 独立「EXHOBBY 相册」仍显示整条目的完整 EXHOBBY 图库。
- 普通相册子图库缓存 30 分钟；整条目缓存继续使用短期缓存。
- 自动缓存 GC 最多保留最近 8 个词条，超过 3 天未使用的已跟踪运行缓存自动删除。
- 图片 ID 映射、相册子图库、旧图库元数据会随词条缓存一起回收；v3.5.9 也会根据旧图库路径尝试清理 v3.5.8 以前生成的图片映射。
- 手动清理入口：在 Safari 打开 `https://www.exhobby.net/__hpoi_cache_clear__`。只清理 EXHOBBY 运行缓存，保留 Safari 年龄验证会话和 Bark/通知设置。
- 代理客户端无法直接删除 Hpoi iOS App 自身的系统图片磁盘缓存；减少重复注入和清理脚本缓存可以显著降低继续增长的速度。

## v3.5.8 原生相册 ID 恢复 + EXHOBBY 唯一路由

- 普通 Hpoi 相册恢复原始 `id / itemId / albumId`，不再使用本地代理 ID。
- EXHOBBY 相册改用独立的本地路由 ID，范围位于 `800000000 ~ 999999998`。
- 分配 EXHOBBY ID 时会检查当前词条全部普通相册的 `id / itemId / albumId`，若发生冲突会自动顺延重新分配。
- 同一词条会持久复用同一个 EXHOBBY ID；只有未来 Hpoi 新增相册恰好占用该 ID 时才重新分配。
- 普通相册第一页继续注入当前词条完整 EXHOBBY 图片，后续分页不重复注入。
- 实机词条 `17540411` 的模拟分配结果为 `925222780`，与 `30352997 / 304883 / 32037019 / 320332` 均不重复。

## v3.5.7 普通相册注入 EXHOBBY 图片

- 保留独立「EXHOBBY 相册」入口及 v3.5.6 的单字段导航代理。
- 当前词条下的每一个普通 Hpoi 相册都会记录其 `itemId` 与词条归属。
- 打开任意普通 Hpoi 相册第一页时，在原 Hpoi 图片前加入当前词条完整的 EXHOBBY 图片序列。
- 原 Hpoi 图片不会被删除；后续分页不重复注入 EXHOBBY 图片。
- 被 v3.5.6 代理的第一张普通相册与其它未代理普通相册使用同一注入逻辑。
- 按实机词条 `17540411` 的 116 张 EXHOBBY 图模拟验证：普通相册第一页返回 116 张 EXHOBBY + 原 Hpoi 图片，第二页开始仅返回原 Hpoi 分页。

## v3.5.6 单字段导航代理

- 修复 Hpoi 会按 `itemId` 回查相册对象，导致 EXHOBBY 卡片与原生相册共享 `itemId` 时总是打开原生相册的问题。
- EXHOBBY 保留真实原生 `itemId` 作为首次点击路由；对应原生相册只把自己的 `itemId` 临时改成本地代理 ID，原生 `id` 完全不改。
- 原生相册请求发往 Hpoi 前，仅把代理 `itemId` 还原成真实值；响应回到 App 后再恢复代理 `itemId`。
- `album/detail`、`pic/list/relate-v2` 都按同一规则处理，因此原生相册图片分页保持可用。
- 其它未被借用的原生相册保持完全原样。
- 按实机日志中的 `item=17540411`、`id=30352997 itemId=304883` 模拟验证：EXHOBBY 首屏返回 20/116 张；被代理的原生相册仍能透明访问 `304883`；其它原生相册不受影响。

## v3.5.5 双阶段相册导航修复

- 修复 EXHOBBY 相册卡片能显示正确图片总数，但点击后实际进入普通 Hpoi 相册的问题。
- 针对当前 Hpoi iOS 的真实导航行为，EXHOBBY 卡片现在使用“合成 `id` + 真实原生 `itemId`”进行第一次点击。
- `album/detail` 同时携带两个字段时，脚本通过唯一的合成 `id` 精确识别 EXHOBBY，不会把普通 Hpoi 相册误判成 EXHOBBY。
- EXHOBBY 的 `album/detail` 响应会把 `id / itemId` 都切回合成路由，因此后续 `pic/list/relate-v2` 只进入 EXHOBBY 图片列表。
- 被借用的真实 `itemId` 只用于第一次点击，不会劫持或修改对应普通 Hpoi 相册。
- 按实机日志中的 `item=17540411`、原生相册 `id=30352997 itemId=304883` 模拟验证：EXHOBBY 首屏返回 20/116 张，普通相册仍为 `virtual=none`。

## v3.5.4 强制绕过 Quantumult X 远程脚本缓存

- 远程订阅使用独立的版本化运行文件；v3.7.0 当前路径为 `hpoi-exhobby-v3.7.0.js`，请求、响应与 EXHOBBY 会话捕获使用同一物理版本。
- 不再仅依赖 `?v=` 查询参数规避缓存，避免 Quantumult X 出现 request-body 仍运行旧脚本、response-body 已更新的半更新状态。
- 每个 Hpoi 请求都会输出 `runtime=v3.5.4 phase=request endpoint=...`，用于确认实际运行版本。
- 保留 v3.5.3 的安全路由诊断；仍不会记录 utoken、Cookie 或 Authorization。

## v3.5.3 相册导航诊断

- 保留 v3.5.2 的图片行模板防降级修复。
- 新增 Hpoi 相册导航日志，只记录 `id / itemId / albumId / picId / itemType / subType / page / pageSize` 等公开路由字段。
- 不记录 `utoken`、Cookie、Authorization 或其它账号凭据。
- 用于定位“词条卡片能显示 EXHOBBY 图片数量，但点击后没有触发 EXHOBBY 图片分页”的情况。
- 正常点击 EXHOBBY 后应能从 `route request endpoint=...` 日志看出 Hpoi 实际采用了哪个字段导航。

## v3.5.2 图片行模板防降级修复

- 修复先学到正确 `subType=official`，随后被不含 `subType` 的其它 Hpoi 图片响应覆盖，导致 EXHOBBY 图片再次无法渲染的问题。
- 图片行模板现在采用“非降级合并”：新响应有值时更新；新响应缺少、为空或为 `null` 时保留此前已经学到的字段。
- 外层图片行与内部 `pictureInfo` 都采用相同的保留策略，避免后续普通相册响应把更完整的模板降级。
- 日志若出现 `subType=official preserved`，表示当前响应没有该字段，但脚本成功保留了此前的正确值。

## v3.5.1 EXHOBBY 图片网格兼容修复

- 修复 EXHOBBY 相册详情能正确显示图片总数（例如 42 张），但打开后图片网格为空的问题。
- Hpoi 原生 `/api/pic/list/relate-v2` 的每个列表项除了 `id / rank / pictureInfo` 外，还可能依赖 `subType` 等外层字段。
- v3.5.1 不再手工构造最简列表项，而是完整复制一条真实 Hpoi 图片行作为模板，只替换图片 ID、排序和 `pictureInfo`。
- 对从 v3.5.0 升级的设备，打开 EXHOBBY 相册时会利用安全映射得到的原生 Hpoi 响应自动刷新完整图片行模板，无需先手动打开普通相册。
- 普通 Hpoi 相册继续完全原样透传；只有 EXHOBBY 专用相册使用 EXHOBBY 图片。

## v3.5.0 原生相册完全隔离

- 移除 v3.4.x 的“借用真实 Hpoi 相册路由 + 普通相册代理”方案。
- EXHOBBY 相册现在只使用自己的本地合成路由，不再占用任何真实 Hpoi 相册的 `id / itemId / albumId`。
- 所有普通 Hpoi 相册的列表对象、详情请求和 `pic/list/relate-v2` 图片分页都保持原样，不再修改、不做代理、不注入 EXHOBBY 图片。
- 旧版留下的 `dedicated-route:*` 和 `album-proxy:*` 本地记录会被新脚本忽略，无需手动清除。
- 只有 EXHOBBY 专用相册会显示 EXHOBBY 图片；普通 Hpoi 相册只显示 Hpoi 自己的图片。
- 更新后请彻底结束 Hpoi，并重新进入词条一次，让 App 重新获取未代理的原生相册列表。

## v3.4.4 部分相册“相册不存在”修复

- 修复 v3.4.3 借用真实 Hpoi 相册路由时，把 `id / itemId / albumId` 全部改成代理 ID，导致部分相册内部 ID 语义被破坏的问题。
- 现在会根据已采集的正常 `album/detail` 与 `pic/list/relate-v2` 请求模板自动识别真正承担导航的字段。
- 只代理实际路由字段；相册对象自身 `id`、关联 ID 等非路由字段保持 Hpoi 原值。
- EXHOBBY 专用入口同样保留原生相册对象结构，只接管真实导航字段，因此不同结构的相册兼容性更高。
- 已有 v3.4.3 的代理记录会在再次打开词条相册列表时自动刷新，无需清空全部缓存。

## v3.4.3 独立 EXHOBBY 入口

- 调整 v3.4.2 的相册链路：不再把当前词条的全部 EXHOBBY 图片注入每一个普通 Hpoi 相册。
- 词条相册列表只新增一个「EXHOBBY 相册」。打开后按 Hpoi 原生分页显示该词条在 EXHOBBY 中的全部图片，不混入普通 Hpoi 图片。
- 为兼容必须使用真实相册路由的 Hpoi 版本，专用入口会保留一个真实原生路由；对应的普通 Hpoi 相册使用透明的本地代理路由，返回内容仍是原来的 Hpoi 相册与图片。
- 其他普通相册完全不改写；专用相册和普通相册的内容链路彼此隔离。
- 专用入口继续使用 EXHOBBY 第一张实图作为预览，不插入 EXHOBBY 标识封面。
- 升级不需要清除图库缓存、年龄验证 Cookie 或重新初始化模板。

## v3.4.2 首页相册与无封面图片序列

- 修复部分 Hpoi 版本中，词条首页的独立「EXHOBBY 相册」仍无法打开、只有普通相册内图片序列可用的问题。
- 首页入口现在使用双通道路由：保留唯一的本地合成 `id`，同时保留一个真实普通相册的 `itemId` 作为兼容后备。客户端无论读取哪种字段，都能进入可用的图片查看链路。
- 首页 EXHOBBY 相册卡片改用当前图库第一张实图作为预览图，不再使用 EXHOBBY 标识封面。
- v3.4.2 的普通 Hpoi 相册第一页曾返回「完整 EXHOBBY 图片序列 + 原 Hpoi 图片」；此行为已在 v3.4.3 删除。
- 原 Hpoi 图片不会被替换或删除；EXHOBBY 图片只在第一页插入，后续分页不会重复出现。
- 升级不需要清除图库缓存、年龄验证 Cookie 或重新初始化模板。

## v3.4.1 相册内查看链路修复

- 修复 v3.4.0 在普通 Hpoi 相册中只插入一张 EXHOBBY 封面、点击后只能把它当作普通单图查看的问题。
- Hpoi 的图片列表不会按返回数据里的 `itemType=album` 执行跨相册跳转，因此 v3.4.1 不再依赖这一无效点击路径。
- v3.4.1 的普通相册第一页返回「EXHOBBY 标识封面 + 当前词条完整 EXHOBBY 图片序列 + 原 Hpoi 图片」；该封面项已在 v3.4.2 移除。
- 原 Hpoi 图片不会被替换或删除；EXHOBBY 序列只在第一页注入，后续分页不会重复出现。
- 外层词条相册列表中的独立「EXHOBBY 相册」入口保持不变，仍可直接进入虚拟相册。

## v3.4.0 相册内 EXHOBBY 入口

- 除词条相册列表顶部的「EXHOBBY 相册」外，现在进入当前词条的任意普通 Hpoi 相册后，第一页图片列表顶部也会出现一个 EXHOBBY 入口。
- 入口使用同一张 EXHOBBY 标识封面，不替换、不删除原 Hpoi 图片；普通相册第二页及后续分页不会重复插入。
- 脚本会在词条相册列表加载时记录“普通相册 ID → 当前词条”的本地映射，因此不同词条、不同普通相册会进入各自对应的 EXHOBBY 图库。
- v3.4.0 曾尝试依靠图片项里的虚拟相册 ID 触发跳转；实机确认 Hpoi 会把该项固定当作普通图片，现已由 v3.4.1 的连续查看序列取代。
- 升级不需要清除图库缓存、年龄验证 Cookie 或重新初始化模板。更新 Quantumult X 的远程重写资源即可。

## v3.3.3 原生相册字段兼容修复

- 修复 Hpoi 在打开 EXHOBBY 虚拟相册时，原生 `/api/album/detail` 等请求可能由 `id` 改用 `itemId`，导致脚本报 `unrecognized native album request field: itemId` 的问题。
- 当正常 Hpoi 相册模板和虚拟相册请求使用不同 ID 字段名时，脚本现在会使用模板中的真实安全 ID 对虚拟字段进行重映射，再在响应阶段替换为 EXHOBBY 相册内容。
- 虚拟的 10 亿级相册 ID 和图片合成 ID 不再因为字段名变化而直接落到 Hpoi 后端，从而避免 App 显示“相册不存在”。
- 新增 `itemId` 字段变体回归测试；远程主脚本 URL 提升为 `v=3.3.3` 以绕过 Quantumult X 旧缓存。

## v3.3.2 冷启动稳定性修复

- Hpoi 自家开屏广告接口 `/api/common/advert/list` 不再使用 `reject-dict` 强制替换为 `{}`。
- 新增 `hpoi-ad-sanitize.js`：保留服务器原有 JSON 外层结构，只把广告响应中的数组清空，避免 App 冷启动仍按原字段读取时发生闪退。
- 新脚本采用 **fail-open**：响应不是合法 JSON、没有可安全清理的数组或后端结构发生未知变化时，直接返回原始响应，优先保证 Hpoi 能启动。
- EXHOBBY 相册逻辑、淘宝关联商品清理和 MITM 域名保持不变。
- 升级后请在 Quantumult X 中手动更新 `HPOI_EXHOBBY` 远程重写资源，再从后台彻底结束 Hpoi 后进行冷启动测试。

## v3.3.1 冷启动兼容修复

- 修复开启 Quantumult X 时 Hpoi 冷启动闪退、必须先关闭圈叉进入一次才能恢复的问题。
- 第三方广告 SDK 域名不再加入 MITM，也不再返回正文为空的 `HTTP 200`；这些域名只在 `hpoi-ads-filter.list` 的分流层拒绝。
- 广告过滤订阅只包含第三方广告域名；需要直连 Hpoi 时，在 `[filter_local]` 单独设置 `hpoi.net.cn` 和 `hpoi.net`。
- 保留 EXHOBBY 原生相册、Hpoi 自家开屏广告接口清空，以及词条下方淘宝关联商品清空。

## v3.3 更新

- 修复部分旧版 iOS／Safari 从 `http://www.exhobby.net` 打开图库时，HTTPS 会话捕获规则完全不执行的问题。
- 在脚本规则之前使用 `307` 自动升级到 HTTPS，保留「更多／More」分页请求的 POST 方法、Cookie 和请求体。
- 不更改相册缓存结构、合成 ID 或标识封面；从 v3.2 升级无需清除现有数据，也无需重新初始化普通 Hpoi 相册模板。

## 功能

- 从当前 Hpoi 词条识别 EXHOBBY 图库，无需逐个填写条目 ID。
- 获取图库第一页及后续分页，收到空数组后才标记抓取完成，不把六张预览图当作完整图库。
- 在原有相册列表中添加入口，保留 Hpoi 自带相册。
- 在每个词条的相册列表中新增一个独立 EXHOBBY 入口，普通 Hpoi 相册内容不变。
- EXHOBBY 专用相册显示该词条的完整 EXHOBBY 图库，并使用第一张实图作为预览；图库图片不添加水印。
- 支持原生相册分页、不同词条之间的缓存隔离和中断后继续获取。
- 沿用 v2.3 已保存的浏览器会话和原生相册模板。
- 只有在缺少会话或网站明确返回年龄／人机验证页面时通知，45 分钟内不重复提醒；已有 Cookie 仍可使用时自动复用。
- 自动把旧设备产生的 EXHOBBY HTTP 图库请求升级为 HTTPS。

适用范围是触发 `/api/hobby/album` 的手办／模型词条；不包含人物、厂商等其他页面。

## 安装

同一台设备只启用一种客户端的本项目配置，避免同一响应被重复处理。

以下远程地址指向原仓库 `main`；请先把交付包中的 v3.7.2 文件上传到该仓库根目录。发布前可先用本地文件测试，尚不存在于远端的链接不会生效。

### Quantumult X

远程重写地址：[hpoi-exhobby.snippet](https://raw.githubusercontent.com/colorfullife123/hpoi-exhobby-qx/main/hpoi-exhobby.snippet)。在现有配置的 `[rewrite_remote]` 中添加：

```ini
https://raw.githubusercontent.com/colorfullife123/hpoi-exhobby-qx/main/hpoi-exhobby.snippet, tag=HPOI_EXHOBBY, enabled=true
```

保存并更新远程资源，确认资源成功加载。相册运行时继续使用 `hpoi-exhobby-v3.7.0.js`；官方开屏脚本应为新的固定路径 `hpoi-ad-sanitize-v3.7.2.js`。

如果通过圈叉的重写资源界面添加，资源地址填写上面的订阅链接。配置行用于 `[rewrite_remote]`，不要把仓库首页链接或 JS 文件链接当作重写订阅地址。

### Surge

在 Surge 的模块页面安装：

```text
https://raw.githubusercontent.com/colorfullife123/hpoi-exhobby-qx/main/hpoi-exhobby.sgmodule
```

启用模块、Rewrite 和 MITM，并安装且信任 Surge 证书。模块包含相册脚本、第三方广告拒绝规则、淘宝接口清理、URL 跳转和三个 MITM 域名；官方开屏接口只保留一个明确的官方记录，其他响应字段不变。

### Loon

在 Loon 的插件页面安装：

```text
https://raw.githubusercontent.com/colorfullife123/hpoi-exhobby-qx/main/hpoi-exhobby.plugin
```

启用插件、脚本和 MITM，并安装且信任 Loon 证书。插件包含完整相册功能和第三方广告拒绝规则；官方开屏接口只保留一个明确的官方记录，其他响应字段不变。

### Clash / Mihomo

把 [`hpoi-clash-example.yaml`](hpoi-clash-example.yaml) 中的 `rule-providers` 与 `rules` 合并进现有配置。它会订阅 [`hpoi-ads-clash.yaml`](hpoi-ads-clash.yaml)，并通过 `RULE-SET,hpoi-ads,REJECT` 拦截第三方广告域名。

Clash/Mihomo **不能安装** `.snippet`、`.sgmodule` 或 `.plugin`，也不能实现 EXHOBBY 相册注入、官方开屏记录筛选和淘宝关联商品接口清理。

### 共享设置：保持脚本与 MITM 开启

**MITM 总开关、已安装并信任的证书都需要保留。** 本项目依赖 MITM 读取和改写 Hpoi、EXHOBBY 的 HTTPS 请求和响应。

以下三个域名需要在 MITM 中生效：

```text
www.hpoi.net.cn, rfx.hpoi.net, www.exhobby.net
```

Quantumult X、Surge 和 Loon 的远程配置都已包含这三个 `hostname`。原来手动添加的相同域名可以保留；若域名尚未生效，将它们追加到客户端现有 MITM 域名列表，保留其他项目需要的域名。

不要把 `fancyapi.com`、`gdt.qq.com`、`pangolin-sdk-toutiao.com`、`zhangyuyidong.cn` 等第三方广告 SDK 域名加入 MITM。部分广告 SDK 会把正文为空的成功响应当成有效数据继续解析，导致 Hpoi 在没有缓存的冷启动阶段闪退；这些域名只在规则层拒绝。

**Quantumult X 如果仍使用旧版 `hpoi-ads-filter.list`，请更新该远程资源。** 旧版曾把 Hpoi 直连规则放在广告订阅里；若订阅行带 `force-policy=reject`，会把它们也改为拒绝，导致 Hpoi 无法连接服务器。新版广告订阅已移除直连规则。

需要固定直连 Hpoi 时，将以下两条规则加入现有配置的 `[filter_local]`，放在宽泛的代理／拒绝规则之前：

```ini
host-suffix, hpoi.net.cn, direct
host-suffix, hpoi.net, direct
```

如果更新远程资源前 Hpoi 已经无法连接，先暂时停用 `HPOI_ADS` 过滤订阅，确认恢复后再更新并开启。刷新后检查 `hpoi-ads-filter.list` 中不再含有 `hpoi.net.cn`／`hpoi.net` 规则。

**从本地规则切换过来时，只停用本项目旧的本地重写，MITM 保持开启。** 同时停用旧版 Hpoi 预览图重写、`hpoi-diag.js` 和 `exhobby-page-diag.js` 诊断规则，避免同一响应被重复处理。

### 首次准备原生相册模板

打开一个正常的 Hpoi 相册并等待图片出现。看到下面的日志说明相册详情模板已保存；图片列表也需要正常加载。

```text
[HPOI_EXHOBBY] native album template ready
```

已经完成过初始化的用户通常无需重复。

### 首次准备 EXHOBBY 会话

保持正在使用的 Quantumult X、Surge 或 Loon 开启，在 Safari 打开 [EXHOBBY 搜索页](https://www.exhobby.net/search)，搜索一个有图库的 Hpoi 词条链接，按照网站要求完成年龄确认，进入图库并点击一次「更多／More」。如果旧设备收到的是 HTTP 链接，规则会先用 `307` 自动升级为 HTTPS，再由脚本保存会话。

看到以下日志后返回 Hpoi：

```text
[HPOI_EXHOBBY] v3.7.0 browser session saved; reopen Hpoi
```

这是保存当前设备正常访问图库所使用的浏览器会话，不需要手动复制 Cookie，也不需要对每个词条分别操作。会话失效后重复此步骤即可。

### 使用

重新进入有 EXHOBBY 图库的 Hpoi 词条，找到「EXHOBBY 相册」并打开，向下滑动加载后续图片。

首次进入时脚本会获取完整图库的**图片路径和元数据**，图片文件在浏览时按需请求。图片较多或网络较慢时，可能需要返回词条刷新，继续获取尚未完成的分页。

## 验证到期提醒

如果 EXHOBBY 会话尚未保存，或网站明确返回年龄／人机验证页面，脚本会通过当前客户端发出通知。请先在 iPhone 设置中允许 Quantumult X、Surge 或 Loon 通知。v3.7.0 会按各客户端格式附带点击跳转地址，并同时把网址写入正文。

也可以选用 [Bark](https://github.com/Finb/Bark)。本项目会优先发送 Bark，发送失败时退回当前代理客户端的本地通知。验证只会在打开 Hpoi 对应词条时检测，不会在后台定时检查。配置方法：

1. 在 iPhone 安装 Bark 并复制 App 提供的测试推送地址，例如 `https://api.day.app/你的密钥/测试内容`。
2. 把仓库中的 [`bark-setup.example.js`](bark-setup.example.js) **复制到手机本地**，文件名可改为 `bark-setup.js`。仅在本地把 `pushURL` 改成 `https://api.day.app/你的密钥`，不要包含 `/测试内容`，也不要把改过的文件上传 GitHub。
3. 在当前客户端中把它作为一次性本地任务或通用脚本运行。看到「Bark 已配置」后，移除含密钥的本地脚本。推送地址会保存在当前客户端的本地脚本存储中。

对**已访问过**的词条，提醒优先打开先前保存的具体相册链接；首次访问且尚未取得相册链接时，会打开 EXHOBBY 搜索页，需要在站内找到目标图库。完成网站要求的确认、进入图库并点击一次「更多／More」后，返回 Hpoi 刷新词条。脚本不会替用户点击年龄确认或绕过人机验证；只会继续使用网站仍接受的已有会话。

使用 Bark 时，推送服务器会收到通知文案和目标 EXHOBBY 链接；不会收到 Hpoi `utoken` 或 EXHOBBY Cookie。Bark 推送密钥保存在手机本地，不进入 GitHub 仓库。

## 从旧版升级与日常更新

从 v3.7.1 升级到 v3.7.2，需要同时更新客户端中的 `HPOI_EXHOBBY` 重写／模块／插件和第三方广告规则。更新后确认 `/api/common/advert/list` 使用 `hpoi-ad-sanitize-v3.7.2.js`，再彻底结束 Hpoi 冷启动。EXHOBBY 缓存和 Safari 年龄验证会话无需清除。

从 v3.7.0 升级到 v3.7.1，只需上传新增的 `hpoi-ad-sanitize-v3.7.1.js` 及本版本配置文件，然后在客户端更新一次远程资源。相册、Safari 会话和缓存结构未变化，无需清缓存或重新验证年龄。

从 Quantumult X v3.6.2 升级到 v3.7.0，只需更新 `HPOI_EXHOBBY` 远程资源，确认脚本路径为 `hpoi-exhobby-v3.7.0.js`。存储命名空间未改变，已有相册模板、图库缓存和仍有效的 Safari 会话可以继续使用。改用 Surge 或 Loon 时，由于各客户端本地脚本存储彼此独立，需要重新完成一次原生相册模板和 Safari 会话准备。

已经使用本地 v2.3／v3.0／v3.1／v3.2 的用户，添加并成功加载远程订阅后，停用旧的本地重写即可。脚本继续使用原有存储命名空间，已保存的相册模板与仍有效的浏览器会话通常可以复用，无需主动清空数据。

从远程 v3.2 升级时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。确认资源中新增的 HTTP `307` 规则排在 HTTPS 会话捕获规则之前；不需要重新上传或改名 `assets/exhobby-cover-v3.2.png`。

从 v3.1 或更早版本升级时，仍需确认主脚本、两份重写配置以及 `assets/exhobby-cover-v3.2.png` 都已在仓库中；封面规则必须排在 EXHOBBY 图片通用跳转规则之前。

从 v3.5.1 升级到 v3.5.2 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源，确认当前主脚本地址带 `hpoi-exhobby-v3.7.0.js`。无需清缓存或重新年龄验证；脚本会保留已经学到的完整图片行字段。

从 v3.5.0 升级到 v3.5.1 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源，确认当前主脚本地址带 `hpoi-exhobby-v3.7.0.js`。不需要清除图库缓存或重新验证年龄；首次重新打开 EXHOBBY 相册时会自动刷新完整原生图片行模板。

从 v3.4.x 升级到 v3.5.0 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源，确认当前主脚本地址带 `hpoi-exhobby-v3.7.0.js`。随后彻底结束 Hpoi 并重新打开出现问题的词条。新版本会忽略旧的普通相册代理记录，无需清空 EXHOBBY 图库缓存，也无需重新做年龄验证。

从 v3.4.3 升级到 v3.4.4 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源，确认当前主脚本地址带 `hpoi-exhobby-v3.7.0.js`。建议更新后重新进入出现过“相册不存在”的词条一次，让该词条的真实路由与代理记录按新规则刷新；不需要清除 EXHOBBY 图库缓存或重新做年龄验证。

从 v3.4.2 升级到 v3.4.3 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。确认主脚本地址带 `hpoi-exhobby.js?v=3.4.3`，再彻底结束 Hpoi 并重新打开。已有图库缓存、原生相册模板和浏览器验证会话都会保留；升级后 EXHOBBY 图片只出现在独立入口，普通 Hpoi 相册恢复原内容。

从 v3.4.1 升级到 v3.4.2 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。确认主脚本地址带 `hpoi-exhobby.js?v=3.4.2`，再彻底结束 Hpoi 并重新打开。已有图库缓存、普通相册映射和浏览器验证会话都会保留；普通相册内不再显示 EXHOBBY 封面项。

从 v3.4.0 升级到 v3.4.1 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。主脚本地址应更新为 `hpoi-exhobby.js?v=3.4.1`；图库缓存、普通相册映射及浏览器验证会话都会保留。打开普通相册后，点击顶部 EXHOBBY 封面并继续滑动即可查看完整图库。

从 v3.3.3 升级到 v3.4.0 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。主脚本地址应更新为 `hpoi-exhobby.js?v=3.4.0`。进入词条一次以建立普通相册到词条的映射，之后打开该词条任意普通相册即可看到 EXHOBBY 入口。

从 v3.3.2 升级到 v3.3.3 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。更新后主脚本地址应带 `hpoi-exhobby.js?v=3.3.3`；无需清除已经抓取的 EXHOBBY 图库缓存或重新做年龄验证。若之前出现 `unrecognized native album request field: itemId`，更新后直接重新打开对应词条和相册即可。

从 v3.3.1 升级到 v3.3.2 时，只需更新圈叉里的 `HPOI_EXHOBBY` 远程资源。确认 `/api/common/advert/list` 已变为 `script-response-body .../hpoi-ad-sanitize.js?v=3.3.2`，不再出现 `url reject-dict`。随后从后台彻底结束 Hpoi，在圈叉保持开启的情况下重新冷启动。

仓库脚本更新后，在当前客户端中更新远程资源，并查看运行日志里的版本号确认实际加载的版本。GitHub 文件修改不等于设备已经更新，远程脚本缓存也可能需要刷新。

只有日志提示模板缺失或会话失效时，才重新执行相应的初始化步骤。已保存的浏览器 Cookie 会在网站仍接受时继续复用，网站要求再次验证时才提醒。

## 本地安装（备选）

Quantumult X 如需使用本地文件，将 [`hpoi-exhobby.js`](hpoi-exhobby.js) 和 [`hpoi-ad-sanitize.js`](hpoi-ad-sanitize.js) 保存为本地脚本，并将 [`hpoi-exhobby.local.conf`](hpoi-exhobby.local.conf) 中的规则合并到现有 `[rewrite_local]` 段，同时保留上述 MITM 设置。Surge 和 Loon 推荐直接使用各自模块/插件，避免手工拆分规则。

本地配置文件是配置片段，不要用它覆盖整份圈叉配置。本地和远程两种安装方式选择一种，避免两套规则同时执行。

脚本原文地址：[hpoi-exhobby.js](https://raw.githubusercontent.com/colorfullife123/hpoi-exhobby-qx/main/hpoi-exhobby.js)。当前脚本以 `// Hpoi + EXHOBBY native album v3.7.0` 开头；`Unsupported Media Type`、HTML 错误页和 Markdown 代码围栏都不能作为 JavaScript 保存。

## 仓库文件与维护

当前订阅使用 `main` 分支。GitHub 文件列表上方的 `main` 下拉按钮表示当前分支；文件根目录是打开仓库后直接看到的第一层文件列表。

| 路径 | 用途 |
| --- | --- |
| `README.md` | 安装、使用和排错说明 |
| `hpoi-exhobby.js` | Quantumult X、Surge、Loon 共用主脚本 |
| `hpoi-exhobby-v3.7.0.js` | 远程订阅使用的 v3.7.0 固定路径运行文件 |
| `hpoi-ad-sanitize.js` | 定向保留一个明确官方开屏记录的维护脚本 |
| `hpoi-ad-sanitize-v3.7.1.js` | 兼容 v3.7.1 旧固定路径的无改写透传脚本 |
| `hpoi-ad-sanitize-v3.7.2.js` | 三客户端远程配置使用的固定版本开屏脚本 |
| `hpoi-empty-dict.js` | Surge 淘宝关联商品接口空字典响应脚本 |
| `bark-setup.example.js` | 可选的一次性 Bark 本地配置模板；不要上传含个人密钥的副本 |
| `hpoi-exhobby.snippet` | Quantumult X 远程重写订阅 |
| `hpoi-exhobby.local.conf` | 本地安装配置片段 |
| `hpoi-exhobby.sgmodule` | Surge 模块 |
| `hpoi-exhobby.plugin` | Loon 插件 |
| `hpoi-ads-clash.yaml` | Clash/Mihomo classical 广告规则集 |
| `hpoi-clash-example.yaml` | Clash/Mihomo 合并配置示例 |
| `assets/exhobby-cover-v3.2.png` | 仅用于兼容 v3.4.1 旧缓存；v3.4.3 不再插入该封面 |
| `package.json` | 离线检查与测试命令 |
| `tests/native-album.cjs` | EXHOBBY 原生相册离线模拟测试 |
| `tests/ad-sanitize.cjs` | 单官方开屏、同级数组保留与第三方广告拒绝边界测试 |
| `tests/platform-adapters.cjs` | 三客户端运行时与四类配置离线测试 |

上传压缩包时先解压，保持目录结构。主脚本和订阅文件应在仓库根目录；封面图应在 `assets` 文件夹，测试文件应放在 **`tests` 文件夹，末尾带 s**。

如果测试文件误放在根目录，可在 GitHub 打开 `native-album.cjs`，点击编辑按钮，在顶部文件名输入框前加上 `tests/`，使最终路径为 `tests/native-album.cjs`，然后提交。文件夹会随提交创建。修改的是文件路径，测试代码沿用原内容。

远程订阅使用无需登录的 Raw 地址。使用自己的 Fork 时，请同步修改 README 中的订阅地址，以及 `hpoi-exhobby.snippet` 内三个 JavaScript 地址的用户名、仓库名和分支；仅修改订阅链接仍会引用原仓库的脚本。

GitHub 官方说明：[移动文件](https://docs.github.com/en/repositories/working-with-files/managing-files/moving-a-file-to-a-new-location)、[查看分支](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-branches-in-your-repository/viewing-branches-in-your-repository)。

## 常见日志

| 日志或现象 | 含义与处理 |
| --- | --- |
| 订阅或脚本链接返回 `404` | 检查仓库是否允许公开访问、分支是否为 `main`、文件名是否正确，以及文件是否误放进了子文件夹。 |
| `script not found` | 本地模式检查保存位置和文件名；远程模式检查脚本 Raw 地址及资源下载状态。 |
| `Unexpected identifier 'Media'` | 文件可能保存成了下载错误页，重新下载脚本原文。 |
| `initialization: open one normal Hpoi album` | 打开一个普通 Hpoi 相册，让详情与图片列表都加载。 |
| `open the EXHOBBY gallery in Safari...` | 尚无有效浏览器会话，按首次会话步骤操作。 |
| `h1=年齡提醒！` | 返回的是网站年龄提醒页，在 Safari 完成网站要求后重新保存会话。 |
| `EXHOBBY requires browser verification` | 网站明确返回了年龄／人机验证页面，点击 Bark 提醒中的网址并按网页提示操作。 |
| `Bark delivery failed` | 推送服务器暂不可用，脚本已改发当前客户端的本地通知。 |
| Safari 已验证但没有任何脚本日志 | 检查请求地址是否仍为 `http://www.exhobby.net`。v3.3 应先命中 `307` 规则并升级为 HTTPS；更新远程资源后重试。 |
| 词条首页 EXHOBBY 相册无法打开 | 确认已更新到 `v3.4.3`，彻底结束 Hpoi 后重新进入词条；仍异常时提供 `album/detail` 与 `pic/list/relate-v2` 日志。 |
| 普通 Hpoi 相册仍混入 EXHOBBY 图片 | 实际仍在运行 v3.4.2 旧缓存；更新远程资源，确认脚本 URL 带 `v=3.4.3`，再彻底结束 Hpoi。 |
| `empty/missing body; end NOT confirmed` | 本次响应缺失，不能当作图库结束；返回词条刷新重试。 |
| `pagination timeout; refresh to resume` | 已保存本轮进度，返回词条刷新以继续抓取。 |
| `page=N count=0` 后出现 `complete=true` | 收到了结束分页，完整元数据已经缓存。 |
| `native page=1 count=20 total=44` | 原生相册当前返回 20 张，共 44 张，继续滑动加载。 |

## 当前边界

- 依赖 Hpoi 和 EXHOBBY 的现有接口、网页结构及图片域名；站点更新后可能需要调整。
- 使用 Hpoi 原生相册样式，不修改 App 本身的页面布局。
- v3.4.3 不再把标识封面或 EXHOBBY 图片插入普通相册；词条首页的专用卡片使用图库第一张实图。
- EXHOBBY 专用相册使用独立的本地合成路由，普通 Hpoi 相册完全保持原生路由；EXHOBBY 图片使用本地合成 ID。当前只适配浏览，收藏、点赞、评论等操作未适配。
- 完整图库元数据缓存有效期为 10 分钟，未完成抓取的进度有效期为 2 分钟。已有浏览器会话会复用至网站明确要求重新验证；提醒的冷却时间为 45 分钟。
- 词条与相册连续 7 天未查看会自动回收，最多保留最近 32 个词条；Hpoi App 自身维护的图片磁盘缓存不在脚本控制范围内。
- 图片显示使用 EXHOBBY 的 `/pic/n/` 地址，不承诺是上传原始分辨率。

## 数据与隐私

仓库只包含脚本、兼容旧版缓存的原创标识封面资产、规则、文档和使用假数据的测试，不附带实际抓包、账号凭据或图库图片。

脚本通过 Quantumult X `$prefs` 或 Surge/Loon `$persistentStore` 保存浏览器 Cookie、User-Agent、请求关联信息、原生模板、图库元数据和已访问图库的链接。EXHOBBY Cookie 仅用于 `www.exhobby.net` 的 HTTPS 请求；旧 HTTP 链接会在会话捕获前升级。Cookie 不写入脚本文件、不打印到日志，也不上传 GitHub。Hpoi 的 `utoken` 不会被记录到脚本的请求关联缓存或转发给 EXHOBBY；Loon 后备请求指纹只计算公开路由字段。

每台设备需要通过网站正常完成访问要求。提交问题时请提供版本、词条 ID 和相关报错，并先遮盖账号凭据。

## 验证

2026-09-11 的用户实机日志已确认：另一个 Hpoi 词条 `64287`（内部 ID `8274446`）抓取到完整 44 张图、创建相册入口，并返回原生相册第一页 20 张。此记录不代表所有条目和所有 App 版本均已验证。

2026-09-13 的另一台 iOS 16.7.16／Safari 16.6.2 设备实机请求确认：EXHOBBY 的「更多」分页仍可能使用 HTTP POST，且已携带 `is18=yes` 的年龄确认 Cookie；手动改用 HTTPS 后会话成功保存。v3.3 据此加入自动 `307` 升级。

本仓库另有离线模拟测试，覆盖并发词条隔离、专用入口的真实路由、普通相册透明代理与内容隔离、无封面图片序列、分页尾页、相册与图片导航、缓存复用、中断恢复、图片 ID 冲突、验证提醒、凭据隔离，以及 HTTP 图库链接到 HTTPS 的 307 规则顺序与 URL 保真。测试不连接真实站点，不代表所有设备和站点状态均已验证。

v3.7.0 额外用独立运行时夹具验证 Quantumult X、Surge、Loon 的存储、请求/响应关联、状态码、通知与 HTTP 客户端适配，并静态校验 Surge 模块、Loon 插件和 Clash/Mihomo 规则。v3.7.2 验证只收缩被识别的开屏数组、其他配置与素材数组完整保留、未知结构原样放行、旧 v3.7.1 路径无改写透传，同时确认四端第三方广告拒绝规则仍在。现有真实设备记录来自 Quantumult X；Surge 与 Loon 仍建议先在单台设备上观察日志后再长期启用。

安装 Node.js 后在仓库根目录执行，无需安装 npm 依赖：

```sh
npm run check
npm test
```

## 参考

接口调用方式参考 [Exhobby For Hpoi 用户脚本](https://greasyfork.org/zh-CN/scripts/382359-exhobby-for-hpoi/code)。各客户端配置接口可查阅 [Quantumult X 示例](https://github.com/crossutility/Quantumult-X)、[Surge Manual](https://manual.nssurge.com/) 与 [Loon 示例配置](https://github.com/Loon0x00/LoonExampleConfig)。

## 许可证与免责声明

本仓库中由本项目作者原创的代码和文档采用 [MIT License](LICENSE) 发布。

本项目是第三方适配项目，与 Hpoi、EXHOBBY、Quantumult X、Surge、Loon、Clash/Mihomo 及其开发者、运营方不存在官方关联、授权或背书关系。

Hpoi、EXHOBBY 及各代理客户端的名称、商标、接口、网站内容与 EXHOBBY 图库中的图片等第三方内容，其相关权利归各自权利人所有。MIT License 仅适用于本仓库中由本项目作者原创并有权许可的代码与文档，不授予任何第三方内容、商标或素材的使用权。

使用本项目时，请自行遵守相关服务的使用条款以及所在地适用的法律法规。
